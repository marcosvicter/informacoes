<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * TiposSolicitacoes Controller
 *
 * @property \App\Model\Table\TiposSolicitacoesTable $TiposSolicitacoes
 *
 * @method \App\Model\Entity\TiposSolicitaco[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class TiposSolicitacoesController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null
     */
    public function index()
    {
        $tiposSolicitacoes = $this->paginate($this->TiposSolicitacoes);

        $this->set(compact('tiposSolicitacoes'));
    }

    /**
     * View method
     *
     * @param string|null $id Tipos Solicitaco id.
     * @return \Cake\Http\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $tiposSolicitaco = $this->TiposSolicitacoes->get($id, [
            'contain' => []
        ]);

        $this->set('tiposSolicitaco', $tiposSolicitaco);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $tiposSolicitaco = $this->TiposSolicitacoes->newEntity();
        if ($this->request->is('post')) {
            $tiposSolicitaco = $this->TiposSolicitacoes->patchEntity($tiposSolicitaco, $this->request->getData());
            if ($this->TiposSolicitacoes->save($tiposSolicitaco)) {
                $this->Flash->success(__('The tipos solicitaco has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The tipos solicitaco could not be saved. Please, try again.'));
        }
        $this->set(compact('tiposSolicitaco'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Tipos Solicitaco id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $tiposSolicitaco = $this->TiposSolicitacoes->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $tiposSolicitaco = $this->TiposSolicitacoes->patchEntity($tiposSolicitaco, $this->request->getData());
            if ($this->TiposSolicitacoes->save($tiposSolicitaco)) {
                $this->Flash->success(__('The tipos solicitaco has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The tipos solicitaco could not be saved. Please, try again.'));
        }
        $this->set(compact('tiposSolicitaco'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Tipos Solicitaco id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $tiposSolicitaco = $this->TiposSolicitacoes->get($id);
        if ($this->TiposSolicitacoes->delete($tiposSolicitaco)) {
            $this->Flash->success(__('The tipos solicitaco has been deleted.'));
        } else {
            $this->Flash->error(__('The tipos solicitaco could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
