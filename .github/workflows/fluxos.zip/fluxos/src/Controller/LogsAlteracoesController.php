<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * LogsAlteracoes Controller
 *
 * @property \App\Model\Table\LogsAlteracoesTable $LogsAlteracoes
 *
 * @method \App\Model\Entity\LogsAlteraco[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class LogsAlteracoesController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Usuarios', 'Informacoes']
        ];
        $logsAlteracoes = $this->paginate($this->LogsAlteracoes);

        $this->set(compact('logsAlteracoes'));
    }

    /**
     * View method
     *
     * @param string|null $id Logs Alteraco id.
     * @return \Cake\Http\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $logsAlteraco = $this->LogsAlteracoes->get($id, [
            'contain' => ['Usuarios', 'Informacoes']
        ]);

        $this->set('logsAlteraco', $logsAlteraco);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $logsAlteraco = $this->LogsAlteracoes->newEntity();
        if ($this->request->is('post')) {
            $logsAlteraco = $this->LogsAlteracoes->patchEntity($logsAlteraco, $this->request->getData());
            if ($this->LogsAlteracoes->save($logsAlteraco)) {
                $this->Flash->success(__('The logs alteraco has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The logs alteraco could not be saved. Please, try again.'));
        }
        $usuarios = $this->LogsAlteracoes->Usuarios->find('list', ['limit' => 200]);
        $informacoes = $this->LogsAlteracoes->Informacoes->find('list', ['limit' => 200]);
        $this->set(compact('logsAlteraco', 'usuarios', 'informacoes'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Logs Alteraco id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $logsAlteraco = $this->LogsAlteracoes->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $logsAlteraco = $this->LogsAlteracoes->patchEntity($logsAlteraco, $this->request->getData());
            if ($this->LogsAlteracoes->save($logsAlteraco)) {
                $this->Flash->success(__('The logs alteraco has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The logs alteraco could not be saved. Please, try again.'));
        }
        $usuarios = $this->LogsAlteracoes->Usuarios->find('list', ['limit' => 200]);
        $informacoes = $this->LogsAlteracoes->Informacoes->find('list', ['limit' => 200]);
        $this->set(compact('logsAlteraco', 'usuarios', 'informacoes'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Logs Alteraco id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $logsAlteraco = $this->LogsAlteracoes->get($id);
        if ($this->LogsAlteracoes->delete($logsAlteraco)) {
            $this->Flash->success(__('The logs alteraco has been deleted.'));
        } else {
            $this->Flash->error(__('The logs alteraco could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
