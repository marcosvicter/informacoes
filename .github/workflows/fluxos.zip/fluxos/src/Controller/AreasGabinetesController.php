<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * AreasGabinetes Controller
 *
 * @property \App\Model\Table\AreasGabinetesTable $AreasGabinetes
 *
 * @method \App\Model\Entity\AreasGabinete[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class AreasGabinetesController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null
     */
    public function index()
    {
        $areasGabinetes = $this->paginate($this->AreasGabinetes);

        $this->set(compact('areasGabinetes'));
    }

    /**
     * View method
     *
     * @param string|null $id Areas Gabinete id.
     * @return \Cake\Http\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $areasGabinete = $this->AreasGabinetes->get($id, [
            'contain' => ['Informacoes']
        ]);

        $this->set('areasGabinete', $areasGabinete);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $areasGabinete = $this->AreasGabinetes->newEntity();
        if ($this->request->is('post')) {
            $areasGabinete = $this->AreasGabinetes->patchEntity($areasGabinete, $this->request->getData());
            if ($this->AreasGabinetes->save($areasGabinete)) {
                $this->Flash->success(__('The areas gabinete has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The areas gabinete could not be saved. Please, try again.'));
        }
        $this->set(compact('areasGabinete'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Areas Gabinete id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $areasGabinete = $this->AreasGabinetes->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $areasGabinete = $this->AreasGabinetes->patchEntity($areasGabinete, $this->request->getData());
            if ($this->AreasGabinetes->save($areasGabinete)) {
                $this->Flash->success(__('The areas gabinete has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The areas gabinete could not be saved. Please, try again.'));
        }
        $this->set(compact('areasGabinete'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Areas Gabinete id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $areasGabinete = $this->AreasGabinetes->get($id);
        if ($this->AreasGabinetes->delete($areasGabinete)) {
            $this->Flash->success(__('The areas gabinete has been deleted.'));
        } else {
            $this->Flash->error(__('The areas gabinete could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
