<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * Situacoes Controller
 *
 * @property \App\Model\Table\SituacoesTable $Situacoes
 *
 * @method \App\Model\Entity\Situaco[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class SituacoesController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null
     */
    public function index()
    {
        $situacoes = $this->paginate($this->Situacoes);

        $this->set(compact('situacoes'));
    }

    /**
     * View method
     *
     * @param string|null $id Situaco id.
     * @return \Cake\Http\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $situaco = $this->Situacoes->get($id, [
            'contain' => []
        ]);

        $this->set('situaco', $situaco);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $situaco = $this->Situacoes->newEntity();
        if ($this->request->is('post')) {
            $situaco = $this->Situacoes->patchEntity($situaco, $this->request->getData());
            if ($this->Situacoes->save($situaco)) {
                $this->Flash->success(__('The situaco has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The situaco could not be saved. Please, try again.'));
        }
        $this->set(compact('situaco'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Situaco id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $situaco = $this->Situacoes->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $situaco = $this->Situacoes->patchEntity($situaco, $this->request->getData());
            if ($this->Situacoes->save($situaco)) {
                $this->Flash->success(__('The situaco has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The situaco could not be saved. Please, try again.'));
        }
        $this->set(compact('situaco'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Situaco id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $situaco = $this->Situacoes->get($id);
        if ($this->Situacoes->delete($situaco)) {
            $this->Flash->success(__('The situaco has been deleted.'));
        } else {
            $this->Flash->error(__('The situaco could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
