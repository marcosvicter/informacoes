<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Informacoes Model
 *
 * @property \App\Model\Table\UsersTable&\Cake\ORM\Association\BelongsTo $Users
 * @property \App\Model\Table\AreasGabinetesTable&\Cake\ORM\Association\BelongsTo $AreasGabinetes
 * @property \App\Model\Table\TiposInformacoesTable&\Cake\ORM\Association\BelongsTo $TiposInformacoes
 * @property \App\Model\Table\SituacoesTable&\Cake\ORM\Association\BelongsTo $Situacoes
 * @property \App\Model\Table\PrioridadesTable&\Cake\ORM\Association\BelongsTo $Prioridades
 *
 * @method \App\Model\Entity\Informaco get($primaryKey, $options = [])
 * @method \App\Model\Entity\Informaco newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\Informaco[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Informaco|false save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Informaco saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Informaco patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Informaco[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\Informaco findOrCreate($search, callable $callback = null, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class InformacoesTable extends Table
{
    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('informacoes');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');

        $this->belongsTo('Users', [
            'foreignKey' => 'user_id',
            'joinType' => 'INNER'
        ])->setDisplayField('username');
        $this->belongsTo('AreasGabinetes', [
            'foreignKey' => 'areas_gabinete_id',
            'joinType' => 'INNER'
        ])->setDisplayField('nome_area');
        $this->belongsTo('TiposInformacoes', [
            'foreignKey' => 'tipos_informacoe_id',
            'joinType' => 'INNER'
        ])->setDisplayField('nome_tipo');
        $this->belongsTo('Situacoes', [
            'foreignKey' => 'situacoe_id',
            'joinType' => 'INNER'
        ])->setDisplayField('nome_situacao');
        $this->belongsTo('Prioridades', [
            'foreignKey' => 'prioridade_id',
            'joinType' => 'INNER'
        ])->setDisplayField('nome_prioridade');
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id')
            ->allowEmptyString('id', null, 'create');

        $validator
            ->scalar('nome_solicitante')
            ->maxLength('nome_solicitante', 255)
            ->allowEmptyString('nome_solicitante');

        $validator
            ->integer('tel_solicitante')
            ->allowEmptyString('tel_solicitante');

        $validator
            ->dateTime('data_recebimento')
            ->requirePresence('data_recebimento', 'create')
            ->notEmptyDateTime('data_recebimento');

        $validator
            ->dateTime('data_solicitacao')
            ->allowEmptyDateTime('data_solicitacao');

        $validator
            ->scalar('email_solicitante')
            ->maxLength('email_solicitante', 255)
            ->allowEmptyString('email_solicitante');

        $validator
            ->requirePresence('informacao', 'create')
            ->notEmptyString('informacao');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        $rules->add($rules->existsIn(['user_id'], 'Users'));
        $rules->add($rules->existsIn(['areas_gabinete_id'], 'AreasGabinetes'));
        $rules->add($rules->existsIn(['tipos_informacoe_id'], 'TiposInformacoes'));
        $rules->add($rules->existsIn(['situacoe_id'], 'Situacoes'));
        $rules->add($rules->existsIn(['prioridade_id'], 'Prioridades'));

        return $rules;
    }
}
