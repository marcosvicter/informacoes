<?php
namespace App\Test\TestCase\Model\Table;

use App\Model\Table\TiposInformacoesTable;
use Cake\ORM\TableRegistry;
use Cake\TestSuite\TestCase;

/**
 * App\Model\Table\TiposInformacoesTable Test Case
 */
class TiposInformacoesTableTest extends TestCase
{
    /**
     * Test subject
     *
     * @var \App\Model\Table\TiposInformacoesTable
     */
    public $TiposInformacoes;

    /**
     * Fixtures
     *
     * @var array
     */
    public $fixtures = [
        'app.TiposInformacoes'
    ];

    /**
     * setUp method
     *
     * @return void
     */
    public function setUp()
    {
        parent::setUp();
        $config = TableRegistry::getTableLocator()->exists('TiposInformacoes') ? [] : ['className' => TiposInformacoesTable::class];
        $this->TiposInformacoes = TableRegistry::getTableLocator()->get('TiposInformacoes', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    public function tearDown()
    {
        unset($this->TiposInformacoes);

        parent::tearDown();
    }

    /**
     * Test initialize method
     *
     * @return void
     */
    public function testInitialize()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test validationDefault method
     *
     * @return void
     */
    public function testValidationDefault()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
