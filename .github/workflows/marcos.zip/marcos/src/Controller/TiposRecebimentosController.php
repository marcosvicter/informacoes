<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * TiposRecebimentos Controller
 *
 * @property \App\Model\Table\TiposRecebimentosTable $TiposRecebimentos
 *
 * @method \App\Model\Entity\TiposRecebimento[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class TiposRecebimentosController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null
     */
    public function index()
    {
        $tiposRecebimentos = $this->paginate($this->TiposRecebimentos);

        $this->set(compact('tiposRecebimentos'));
    }

    /**
     * View method
     *
     * @param string|null $id Tipos Recebimento id.
     * @return \Cake\Http\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $tiposRecebimento = $this->TiposRecebimentos->get($id, [
            'contain' => []
        ]);

        $this->set('tiposRecebimento', $tiposRecebimento);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $tiposRecebimento = $this->TiposRecebimentos->newEntity();
        if ($this->request->is('post')) {
            $tiposRecebimento = $this->TiposRecebimentos->patchEntity($tiposRecebimento, $this->request->getData());
            if ($this->TiposRecebimentos->save($tiposRecebimento)) {
                $this->Flash->success(__('The tipos recebimento has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The tipos recebimento could not be saved. Please, try again.'));
        }
        $this->set(compact('tiposRecebimento'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Tipos Recebimento id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $tiposRecebimento = $this->TiposRecebimentos->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $tiposRecebimento = $this->TiposRecebimentos->patchEntity($tiposRecebimento, $this->request->getData());
            if ($this->TiposRecebimentos->save($tiposRecebimento)) {
                $this->Flash->success(__('The tipos recebimento has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The tipos recebimento could not be saved. Please, try again.'));
        }
        $this->set(compact('tiposRecebimento'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Tipos Recebimento id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $tiposRecebimento = $this->TiposRecebimentos->get($id);
        if ($this->TiposRecebimentos->delete($tiposRecebimento)) {
            $this->Flash->success(__('The tipos recebimento has been deleted.'));
        } else {
            $this->Flash->error(__('The tipos recebimento could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
