<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Informaco Entity
 *
 * @property int $id
 * @property int $user_id
 * @property int $areas_gabinete_id
 * @property int $tipos_informacoe_id
 * @property string|null $nome_solicitante
 * @property int|null $tel_solicitante
 * @property \Cake\I18n\FrozenTime $data_recebimento
 * @property \Cake\I18n\FrozenTime|null $data_solicitacao
 * @property string|null $email_solicitante
 * @property int $situacoe_id
 * @property int $prioridade_id
 * @property string|resource $informacao
 * @property \Cake\I18n\FrozenTime|null $created
 * @property \Cake\I18n\FrozenTime|null $modified
 *
 * @property \App\Model\Entity\User $user
 * @property \App\Model\Entity\AreasGabinete $areas_gabinete
 * @property \App\Model\Entity\TiposInformaco $tipos_informaco
 * @property \App\Model\Entity\Situaco $situaco
 * @property \App\Model\Entity\Prioridade $prioridade
 */
class Informaco extends Entity
{
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'user_id' => true,
        'areas_gabinete_id' => true,
        'tipos_informacoe_id' => true,
        'nome_solicitante' => true,
        'tel_solicitante' => true,
        'data_recebimento' => true,
        'data_solicitacao' => true,
        'email_solicitante' => true,
        'situacoe_id' => true,
        'prioridade_id' => true,
        'informacao' => true,
        'created' => true,
        'modified' => true,
        'user' => true,
        'areas_gabinete' => true,
        'tipos_informaco' => true,
        'situaco' => true,
        'prioridade' => true
    ];
}
