<?php
namespace App\Test\TestCase\Model\Table;

use App\Model\Table\AreasGabinetesTable;
use Cake\ORM\TableRegistry;
use Cake\TestSuite\TestCase;

/**
 * App\Model\Table\AreasGabinetesTable Test Case
 */
class AreasGabinetesTableTest extends TestCase
{
    /**
     * Test subject
     *
     * @var \App\Model\Table\AreasGabinetesTable
     */
    public $AreasGabinetes;

    /**
     * Fixtures
     *
     * @var array
     */
    public $fixtures = [
        'app.AreasGabinetes',
        'app.Informacoes'
    ];

    /**
     * setUp method
     *
     * @return void
     */
    public function setUp()
    {
        parent::setUp();
        $config = TableRegistry::getTableLocator()->exists('AreasGabinetes') ? [] : ['className' => AreasGabinetesTable::class];
        $this->AreasGabinetes = TableRegistry::getTableLocator()->get('AreasGabinetes', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    public function tearDown()
    {
        unset($this->AreasGabinetes);

        parent::tearDown();
    }

    /**
     * Test initialize method
     *
     * @return void
     */
    public function testInitialize()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test validationDefault method
     *
     * @return void
     */
    public function testValidationDefault()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
