<?php
namespace App\Test\TestCase\Model\Table;

use App\Model\Table\InformacoesTable;
use Cake\ORM\TableRegistry;
use Cake\TestSuite\TestCase;

/**
 * App\Model\Table\InformacoesTable Test Case
 */
class InformacoesTableTest extends TestCase
{
    /**
     * Test subject
     *
     * @var \App\Model\Table\InformacoesTable
     */
    public $Informacoes;

    /**
     * Fixtures
     *
     * @var array
     */
    public $fixtures = [
        'app.Informacoes',
        'app.Users',
        'app.AreasGabinetes',
        'app.TiposInformacoes',
        'app.Situacoes',
        'app.Prioridades'
    ];

    /**
     * setUp method
     *
     * @return void
     */
    public function setUp()
    {
        parent::setUp();
        $config = TableRegistry::getTableLocator()->exists('Informacoes') ? [] : ['className' => InformacoesTable::class];
        $this->Informacoes = TableRegistry::getTableLocator()->get('Informacoes', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    public function tearDown()
    {
        unset($this->Informacoes);

        parent::tearDown();
    }

    /**
     * Test initialize method
     *
     * @return void
     */
    public function testInitialize()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test validationDefault method
     *
     * @return void
     */
    public function testValidationDefault()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test buildRules method
     *
     * @return void
     */
    public function testBuildRules()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test isOwnedBy method
     *
     * @return void
     */
    public function testIsOwnedBy()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
