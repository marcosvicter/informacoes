<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\ORM\TableRegistry;

/**
 * Informacoes Controller
 *
 * @property \App\Model\Table\InformacoesTable $Informacoes
 *
 * @method \App\Model\Entity\Informaco[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class InformacoesController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Users', 'AreasGabinetes', 'TiposInformacoes', 'Situacoes', 'Prioridades']
        ];
        $informacoes = $this->paginate($this->Informacoes);

        $this->set(compact('informacoes'));
    }

    /**
     * View method
     *
     * @param string|null $id Informaco id.
     * @return \Cake\Http\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $informaco = $this->Informacoes->get($id, [
            'contain' => ['Users', 'AreasGabinetes', 'TiposInformacoes', 'Situacoes', 'Prioridades']
        ]);

        $this->set('informaco', $informaco);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $informaco = $this->Informacoes->newEntity();
        if ($this->request->is('post')) {
            $informaco = $this->Informacoes->patchEntity($informaco, $this->request->getData());
            if ($this->Informacoes->save($informaco)) {
                $this->Flash->success(__('The informaco has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The informaco could not be saved. Please, try again.'));
        }
        $users = $this->Informacoes->Users->find('list', ['limit' => 200]);
        $areasGabinetes = $this->Informacoes->AreasGabinetes->find('list', ['limit' => 200]);
        $tiposInformacoes = $this->Informacoes->TiposInformacoes->find('list', ['limit' => 200]);
        $situacoes = $this->Informacoes->Situacoes->find('list', ['limit' => 200]);
        $prioridades = $this->Informacoes->Prioridades->find('list', ['limit' => 200]);
        $this->set(compact('informaco', 'users', 'areasGabinetes', 'tiposInformacoes', 'situacoes', 'prioridades'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Informaco id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $informaco = $this->Informacoes->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $informaco = $this->Informacoes->patchEntity($informaco, $this->request->getData());
            if ($this->Informacoes->save($informaco)) {
                $this->Flash->success(__('The informaco has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The informaco could not be saved. Please, try again.'));
        }
        $users = $this->Informacoes->Users->find('list', ['limit' => 200]);
        $areasGabinetes = $this->Informacoes->AreasGabinetes->find('list', ['limit' => 200]);
        $tiposInformacoes = $this->Informacoes->TiposInformacoes->find('list', ['limit' => 200]);
        $situacoes = $this->Informacoes->Situacoes->find('list', ['limit' => 200]);
        $prioridades = $this->Informacoes->Prioridades->find('list', ['limit' => 200]);
        $this->set(compact('informaco', 'users', 'areasGabinetes', 'tiposInformacoes', 'situacoes', 'prioridades'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Informaco id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $informaco = $this->Informacoes->get($id);
        if ($this->Informacoes->delete($informaco)) {
            $this->Flash->success(__('The informaco has been deleted.'));
        } else {
            $this->Flash->error(__('The informaco could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
	 /**
     * Report method
     *
     * @return \Cake\Http\Response|null
     */
    public function report()
    {
        $this->paginate = [
            'contain' => ['Users', 'AreasGabinetes', 'TiposInformacoes', 'Situacoes', 'Prioridades']
        ];
		
		$users = $this->Informacoes->Users->find('list', ['limit' => 200]);
        $areasGabinetes = $this->Informacoes->AreasGabinetes->find('list', ['limit' => 200]);
        $tiposInformacoes = $this->Informacoes->TiposInformacoes->find('list', ['limit' => 200]);
        $situacoes = $this->Informacoes->Situacoes->find('list', ['limit' => 200]);
        $prioridades = $this->Informacoes->Prioridades->find('list', ['limit' => 200]);
		
		$query = "";
		if(isset($_GET['user_id'])){
		 $query = $this->Informacoes->find()->where(['user_id'=> $_GET['user_id']]);
		}
		if(isset($_GET['areas_gabinete_id'])){
			$this->Informacoes->find()->where(['areas_gabinete_id' => $_GET['areas_gabinete_id']]);
		}
		if(isset($_GET['areas_gabinete_id'])){
			$this->Informacoes->find()->where(['areas_gabinete_id' => $_GET['areas_gabinete_id']]);
		}
		if(isset($_GET['tipos_informacoe_id'])){
			$this->Informacoes->find()->where(['tipos_informacoe_id' => $_GET['tipos_informacoe_id']]);
		}
		if(isset($_GET['nome_solicitante'])){
			$this->Informacoes->find()->where(['nome_solicitante' => $_GET['nome_solicitante']]);
		}
		if(isset($_GET['data_recebimento'])){
			$this->Informacoes->find()->where(['data_recebimento' => $_GET['data_recebimento']]);
		}
		if(isset($_GET['data_recebimento'])){
			$this->Informacoes->find()->where(['data_recebimento' => $_GET['data_recebimento']]);
		}
		if(isset($_GET['data_solicitacao'])){
			$this->Informacoes->find()->where(['data_solicitacao' => $_GET['data_solicitacao']]);
		}
		if(isset($_GET['email_solicitante'])){
			$this->Informacoes->find()->where(['email_solicitante' => $_GET['email_solicitante']]);
		}
		if(isset($_GET['situacoe_id'])){
			$this->Informacoes->find()->where(['situacoe_id' => $_GET['situacoe_id']]);
		}
		if(isset($_GET['prioridade_id'])){
			$this->Informacoes->find()->where(['prioridade_id' => $_GET['prioridade_id']]);
		}
		
        $informacoes = $this->paginate($query);
		$this->set(compact('users', 'areasGabinetes', 'tiposInformacoes', 'situacoes', 'prioridades'));
		$this->set(compact('informacoes'));
        $this->set('_serialize', ['users', 'areasGabinetes', 'tiposInformacoes', 'situacoes', 'prioridades']);
    }
}
