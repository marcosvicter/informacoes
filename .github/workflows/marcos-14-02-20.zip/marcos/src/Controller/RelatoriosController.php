<?php
namespace App\Controller;

use App\Controller\AppController;

class RelatoriosController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Users', 'AreasGabinetes', 'TiposInformacoes', 'Situacoes', 'Prioridades']
        ];
        $informacoes = $this->paginate($this->Informacoes);

        $this->set(compact('relatorios'));
    }
}
